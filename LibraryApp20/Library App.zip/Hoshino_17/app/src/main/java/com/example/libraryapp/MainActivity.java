package com.example.librarymanagementapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Simple boolean to track login status (In real app, check Firebase User)
    private boolean isLoggedIn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupButton(R.id.btnProfile, ProfileActivity.class);
        setupButton(R.id.btnBookStatus, BookStatusActivity.class);
        setupButton(R.id.btnReservation, ReservationActivity.class);
        setupButton(R.id.btnLostFound, LostFoundActivity.class);
        setupButton(R.id.btnReport, ReportActivity.class);
        setupButton(R.id.btnLockers, LockerActivity.class);
        setupButton(R.id.btnFines, PaymentActivity.class);

        Button btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
        });
    }

    private void setupButton(int btnId, Class<?> destinationActivity) {
        Button btn = findViewById(btnId);
        btn.setOnClickListener(v -> {
            if (isLoggedIn) {
                // If logged in, go to the feature
                startActivity(new Intent(MainActivity.this, destinationActivity));
            } else {
                // If not, force Login first
                Toast.makeText(this, "Please Login to use this feature.", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, LoginActivity.class));


            }
        });
    }@Override
    protected void onResume() {
        super.onResume();
        checkLoginStatus();
    }

    private void checkLoginStatus() {
        SharedPreferences sharedPref = getSharedPreferences("LibraryAppSession", Context.MODE_PRIVATE);
        boolean isLoggedIn = sharedPref.getBoolean("isLoggedIn", false);
        String userRole = sharedPref.getString("userRole", "client");

        Button btnLogin = findViewById(R.id.btnLogin);

        if (isLoggedIn) {
            btnLogin.setText("Log Out");
            btnLogin.setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
            btnLogin.setOnClickListener(v -> logout());

            // Example: If Admin, show a hidden Admin Button
            if(userRole.equals("admin")) {
                // Show admin specific buttons here
            }
        } else {
            btnLogin.setText("Login / Admin Access");
            btnLogin.setBackgroundColor(getResources().getColor(R.color.purple_500)); // Or your theme color
            btnLogin.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, LoginActivity.class)));
        }
    }

    private void logout() {
        SharedPreferences sharedPref = getSharedPreferences("LibraryAppSession", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.clear(); // Delete session data
        editor.apply();

        Toast.makeText(this, "Logged Out", Toast.LENGTH_SHORT).show();
        recreate(); // Refresh the page
    }


}

