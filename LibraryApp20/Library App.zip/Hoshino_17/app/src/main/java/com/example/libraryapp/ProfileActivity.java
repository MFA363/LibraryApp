package com.example.librarymanagementapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // In a real app, you would fetch these strings from Database/Firebase
        TextView txtName = findViewById(R.id.txtName);
        TextView txtEmail = findViewById(R.id.txtEmail);

        // Mock Data for now
        txtName.setText("Name: Ali bin Abu");
        txtEmail.setText("Email: ali@student.com");
        // Add other fields (Address, Age, Gender) similarly...
    }
}

